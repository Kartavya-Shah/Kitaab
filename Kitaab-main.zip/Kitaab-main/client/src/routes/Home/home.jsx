import React from 'react'

function Home() {
  return (
    <div>

      <h1>Home</h1>
      <p>Minature Vite + React demo website.</p>
      <p>It uses NodeJs, Express & MongoDB as a backend!</p>

    </div>
  )
}

export default Home;